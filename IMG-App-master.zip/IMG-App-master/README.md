# IMG-App


## Prerequisites:

### Android Studio 2022

### Gradle version : 7.4.2

### If You Are Using Older Version Try To Downgrade Gradle Version 

### It will work smooth For you , Enjoy ! :D

## Screenshots :

### Running The App :

![IMG 1](https://user-images.githubusercontent.com/71633887/226520925-6c2a6f16-c324-4492-8f7a-550e47e5b5cb.JPG)

### Test & Results :

![IMG 2](https://user-images.githubusercontent.com/71633887/226521204-7e4631e4-120d-45c4-97ce-bc1107b12981.JPG)
